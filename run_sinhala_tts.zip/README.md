# Sinhala Text-to-Speech System

A desktop application for converting Sinhala text to speech using a rule-based approach (non-neural network).

## Features

- **Rule-based TTS**: Uses phoneme mapping instead of neural networks
- **Windows Desktop App**: Native GUI application using tkinter
- **Real-time Conversion**: Convert Sinhala text to phonetic representation
- **Audio Controls**: Adjustable speed and volume
- **File Support**: Load text files and save audio output
- **Sample Text**: Includes sample Sinhala text for testing

## Installation

### Prerequisites

- Python 3.6 or higher
- Windows OS (recommended)

### Setup Steps

1. **Clone or download** this project to your computer

2. **Run the setup script**:

   ```bash
   python setup.py
   ```

3. **Start the application**:

   ```bash
   python sinhala_tts_app.py
   ```

   Or double-click `run_sinhala_tts.bat` on Windows

## Usage

### Basic Usage

1. **Enter Sinhala Text**: Type or paste Sinhala text in the input area
2. **Convert to Phonetics**: Click "Convert to Phonetics" to see the phoneme representation
3. **Adjust Settings**: Use sliders to control speech speed and volume
4. **Speak**: Click "Speak" to hear the text
5. **Save Audio**: Click "Save as Audio" to export as WAV file

### Advanced Features

- **Load Sample Text**: Click to load example Sinhala text
- **Load Text File**: Import text from .txt files
- **Clear Text**: Clear all input and output areas
- **Stop Speaking**: Stop current speech synthesis

### Phoneme Mapping

The system uses a comprehensive mapping of Sinhala characters to English phonemes:

#### Vowels

- අ → a, ආ → aa, ඇ → ae, etc.

#### Consonants

- ක → ka, ග → ga, ච → cha, etc.

#### Diacritics

- ා → aa, ි → i, ු → u, etc.

## Technical Details

### Architecture

- **Frontend**: tkinter GUI for Windows desktop
- **TTS Engine**: pyttsx3 (cross-platform)
- **Phoneme Conversion**: Rule-based character mapping
- **Audio Output**: WAV format support

### Non-Neural Network Approach

This system uses traditional rule-based methods instead of neural networks:

- Character-to-phoneme mapping tables
- Pattern-based text processing
- Deterministic conversion rules
- No machine learning training required

### Limitations

- Phoneme quality depends on mapping accuracy
- May not handle complex linguistic rules
- Limited naturalness compared to neural approaches
- Requires manual tuning for better pronunciation

## Customization

### Adding New Phoneme Mappings

Edit the `load_sinhala_phonemes()` method in `sinhala_tts_app.py`:

```python
mappings = {
    'your_character': 'phoneme_representation',
    # Add more mappings here
}
```

### Adjusting TTS Settings

Modify the `setup_tts_engine()` method to change default settings:

```python
self.tts_engine.setProperty('rate', 150)    # Speech rate
self.tts_engine.setProperty('volume', 0.8)  # Volume level
```

## Troubleshooting

### Common Issues

1. **"TTS Engine setup error"**

   - Install additional TTS voices from Windows Settings
   - Restart the application

2. **"No module named 'pyttsx3'"**

   - Run: `pip install pyttsx3`
   - Ensure Python is properly installed

3. **"tkinter not found"**

   - Install python-tk package
   - Use Python from python.org (includes tkinter)

4. **Poor audio quality**
   - Adjust speed and volume settings
   - Try different system TTS voices

### Performance Tips

- Keep text length moderate for better performance
- Use punctuation for natural pauses
- Test with sample text first

## File Structure
